#!/bin/bash
# Check cuda version argument
if [ -z "$1" ]
  then
    echo "Please specify cuda version!"
    exit 1
elif [ "$1" == "10.0" ]
  then
    echo "Installing cuda 10.0, please wait..."
elif [ "$1" == "10.1" ]
  then
    echo "Installing cuda 10.1, please wait..."
elif [ "$1" == "11.0" ]
  then
    echo "Installing cuda 11.0, please wait..."
elif [ "$1" == "11.2" ]
  then
    echo "Installing cuda 11.2, please wait..."
else
    echo "Specify cuda version not supported!"
    exit 1
fi

# Check multiple version argument
if [ -z "$2" ]
  then
    echo "Removing previous cuda installation..."
    sudo apt-get purge nvidia*
    sudo apt-get autoremove
    sudo apt-get autoclean
    sudo rm -rf /usr/local/cuda*
elif [ "$2" == "multiple_version" ]
  then
    echo "Installing cuda version $1 alongside previous cuda installation... "
fi

# Add key
sudo apt-key adv --fetch-keys http://developer.download.nvidia.com/compute/cuda/repos/ubuntu1804/x86_64/7fa2af80.pub
echo "deb https://developer.download.nvidia.com/compute/cuda/repos/ubuntu1804/x86_64 /" | sudo tee /etc/apt/sources.list.d/cuda.list
sudo apt-get update 

# Install cuda
if [ "$1" == "10.0" ]
  then
    echo "Installing cuda 10.0, please wait..."
    sudo apt-get -o Dpkg::Options::="--force-overwrite" install cuda-10-0 cuda-drivers -y
elif [ "$1" == "10.1" ]
  then
    echo "Installing cuda 10.1, please wait..."
    sudo apt-get -o Dpkg::Options::="--force-overwrite" install cuda-10-1 cuda-drivers -y
elif [ "$1" == "11.0" ]
  then
    echo "Installing cuda 11.0, please wait..."
    sudo apt-get -o Dpkg::Options::="--force-overwrite" install cuda-11-0 cuda-drivers -y
elif [ "$1" == "11.2" ]
  then
    echo "Installing cuda 11.2, please wait..."
    sudo apt-get -o Dpkg::Options::="--force-overwrite" install cuda-11-2 cuda-drivers -y
fi

echo "export PATH=/usr/local/cuda-$1/bin"'${PATH:+:${PATH}}' >> ~/.bashrc
echo "export LD_LIBRARY_PATH=/usr/local/cuda-$1"'/lib64${LD_LIBRARY_PATH:+:${LD_LIBRARY_PATH}}' >> ~/.bashrc
source ~/.bashrc
sudo ldconfig

# Download cuDNN
if [ "$1" == "10.0" ]
  then
    FIELD_ID="1RsruDhHGjU3mbyTuJRTTW8JFmNmffW1A"
    FILE_NAME="cudnn-10.0-linux-x64-v7.6.5.32.tgz"
elif [ "$1" == "10.1" ]
  then
    FIELD_ID="1SPx8RsT632wIpWlpUL9exLez4QydTWxl"
    FILE_NAME="cudnn-10.1-linux-x64-v7.6.5.32.tgz"
elif [ "$1" == "11.0" ]
  then
    FIELD_ID="1yrW5CfTyLRAInCcsmQ-OX8Zra_cANtDX"
    FILE_NAME="cudnn-11.0-linux-x64-v8.0.1.13.tgz"
fi

cd ~/Downloads
URL="https://docs.google.com/uc?export=download&id=$FIELD_ID"
wget --load-cookies /tmp/cookies.txt "https://docs.google.com/uc?export=download&confirm=$(wget --quiet --save-cookies /tmp/cookies.txt --keep-session-cookies --no-check-certificate $URL -O- | sed -rn 's/.*confirm=([0-9A-Za-z_]+).*/\1\n/p')&id=$FIELD_ID" -O $FILE_NAME && rm -rf /tmp/cookies.txt

# Decompression cuDNN file and copy
tar -xf $FILE_NAME
sudo cp -R cuda/include/* /usr/local/cuda-10.0/include
sudo cp -R cuda/lib64/* /usr/local/cuda-10.0/lib64
cd -