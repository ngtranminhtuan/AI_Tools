# model_optimization
    Notice: This repo specifically used for the segmentation model. If you want to apply to your project, please modify the code.
## Convert using tf flags & [trt_convert](https://docs.nvidia.com/deeplearning/frameworks/tf-trt-user-guide/index.html)
### Supported mode:
    - TF_FP32, TF_FP16 (using tf flags to cast)
    - TR_FP32, TR_FP16, TR_INT8 (using trt_convert to convert)
### Run:
    python3 tf_trt.py
## [Convert tf to trt through onnx](https://developer.nvidia.com/blog/speeding-up-deep-learning-inference-using-tensorflow-onnx-and-tensorrt/)
### Convert tf to onnx
    bash to_onnx.sh
### Build trt engine
    python3 build.py
### Run trt engine
    python3 run.py
## Useful code
### Test \*.pb \*.onnx model
    python3 run_pb.py
    python3 run_onnx.py