import engine as eng
import argparse
import onnx
from onnx import ModelProto, numpy_helper, helper
import tensorrt as trt 
import numpy as np
import os

engine_name = "ckpt3/model_false_16.plan"
onnx_path = "ckpt3/model_false.onnx"
batch_size = 1 

model = ModelProto()
with open(onnx_path, "rb") as f:
    model.ParseFromString(f.read())


# keep_node = []
# for node_idx, node in enumerate(model.graph.node):
#     if node.op_type == 'Pad':
#         keep_node += [node]
#         for init_idx, init in enumerate(model.graph.initializer):
#             if init.name == node.input[1]:
#                 pad = numpy_helper.to_array(init)
#                 if pad[1] != 0:
#                     model.graph.initializer.remove(init)
#                     model.graph.initializer.insert(init_idx,
#                         helper.make_tensor(init.name, init.data_type, init.dims, np.roll(pad, 1)))

#                     x = node.input[0]
#                     y = node.output[0]
#                     transpose = helper.make_node('Transpose', [x], [x+'transpose'], perm=[0,3,1,2])
#                     node.input[0] = x+'transpose'

#                     keep_node.pop()
#                     keep_node += [transpose, node]

#                     next_node = model.graph.node[node_idx+1]
#                     if next_node.op_type == 'Transpose':
#                         perm0 = next_node.attribute[0]
#                         perm = helper.make_attribute(perm0.name, [1,0,2,3])
#                         next_node.attribute.remove(perm0)
#                         next_node.attribute.append(perm)   
#     else:
#         keep_node += [node]


'''
keep_node = []
for node in model.graph.node:
    if node.op_type == 'BatchNormalization':
        x = node.input[0]
        scale = node.input[1]
        b = node.input[2]
        mean = node.input[3]
        var = node.input[4]
        y = node.output[0]

        # mean = helper.make_node('ReduceMean', [x], [y+'mean'], axes=[0,2,3])
        # sub = helper.make_node('Sub', [x, y+'mean'], [y+'sub'])
        # var_square = helper.make_node('Mul', [y+'sub', y+'sub'], [y+'var_square'])
        # var = helper.make_node('ReduceMean', [y+'var_square'], [y+'var'], axes=[0,2,3])
        # ep_tensor = onnx.helper.make_tensor(y+'ep_tensor', onnx.TensorProto.FLOAT, (1,), [node.attribute[0].f])
        # ep = onnx.helper.make_node('Constant', [], [y+'ep'], value=ep_tensor)
        # var_add_ep = helper.make_node('Add', [y+'var', y+'ep'], [y+'var_add_ep'])
        # std = helper.make_node('Sqrt', [y+'var_add_ep'], [y+'std'])
        # sub_div_std = helper.make_node('Div', [y+'sub', y+'std'], [y+'sub_div_std'])
        # shape_tensor = onnx.helper.make_tensor(y+'shape_tensor', onnx.TensorProto.INT64, (4,), [1,-1,1,1])
        # shape = onnx.helper.make_node('Constant', [], [y+'shape'], value=shape_tensor)
        # bias = helper.make_node('Reshape', [b, y+'shape'], [y+'bias'])
        # add_bias = helper.make_node('Add', [y+'sub_div_std', y+'bias'], [y])
        # keep_node += [mean, sub, var_square, var, ep, var_add_ep, std, sub_div_std, shape, bias, add_bias]
        
        norm = helper.make_node('InstanceNormalization', [x, scale, b], [y], epsilon=node.attribute[0].f)
        keep_node += [norm]
        
        # sub = helper.make_node('Add', [x, x], [y])
        # keep_node += [sub]

    else:
        keep_node.append(node)
'''
# while len(model.graph.node):
#     model.graph.node.pop(0)
# model.graph.node.extend(keep_node)


# for output in model.graph.output[::-1]:
#     if output.name != 'prob_map:0':
#         model.graph.output.remove(output)
# print('OUTPUT\n', model.graph.output)

# onnx.checker.check_model(model)
# onnx_path = list(os.path.splitext(onnx_path))
# onnx_path.insert(-1, '_obn')
# onnx_path = ''.join(onnx_path)
# onnx.save(model, onnx_path)


d0 = model.graph.input[0].type.tensor_type.shape.dim[1].dim_value
d1 = model.graph.input[0].type.tensor_type.shape.dim[2].dim_value
d2 = model.graph.input[0].type.tensor_type.shape.dim[3].dim_value
shape = [batch_size , d0, d1 ,d2]
engine = eng.build_engine(onnx_path, shape=shape)
eng.save_engine(engine, engine_name) 