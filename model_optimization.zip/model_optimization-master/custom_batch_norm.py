import tensorflow as tf
from tensorflow.python.platform import gfile
import numpy as np


sess = tf.Session()
with gfile.FastGFile('ckpt/model.pb', 'rb') as f:
    graph_def = tf.GraphDef()
    graph_def.ParseFromString(f.read())
    sess.graph.as_default()    
    tf.import_graph_def(graph_def)


add_node = []
removed_node = []
for node in sess.graph.as_graph_def().node:
    if node.op == 'FusedBatchNorm':
        epsilon = node.attr['epsilon'].f
        inputs = [sess.graph.get_tensor_by_name(i + ':0') for i in node.input]
        print(node.input[0])
        mean = tf.math.reduce_mean(inputs[0], axis=(0,1,2), keepdims=True)
        var = tf.math.reduce_mean((inputs[0] - mean)**2, axis=(0,1,2), keepdims=True)
        norm = (inputs[0] - mean)/((var + epsilon)**0.5)*inputs[1] + inputs[2]
        new_batch_norm = tf.identity(norm, node.name + '_new') 
        add_node.append(new_batch_norm)
        removed_node.append(node.name)

input_tensor = sess.graph.get_tensor_by_name('import/Placeholder:0')
sess.run(add_node, {input_tensor: np.ones((1,512,512,3))})

graph_def = sess.graph.as_graph_def()
for node in graph_def.node:
    for i, _ in enumerate(node.input):
        if node.input[i] in removed_node:
            node.input[i] += '_new'

with tf.Graph().as_default():
    with tf.Session() as sess:
        tf.import_graph_def(graph_def)

        output_graph_def = tf.graph_util.convert_variables_to_constants(sess, graph_def, ['import/prob_map']) 
        output_graph_def = tf.graph_util.remove_training_nodes(output_graph_def)
        with gfile.GFile('ckpt/model_bn.pb', "wb") as f:
            f.write(output_graph_def.SerializeToString())
