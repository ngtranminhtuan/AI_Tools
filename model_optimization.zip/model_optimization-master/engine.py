import tensorrt as trt

TRT_LOGGER = trt.Logger(trt.Logger.WARNING)
trt_runtime = trt.Runtime(TRT_LOGGER)
def build_engine(onnx_path, shape=[1,224,224,3]):

    """
    This is the function to create the TensorRT engine
    Args:
       onnx_path : Path to onnx_file. 
       shape : Shape of the input of the ONNX file. 
    """
    with trt.Builder(TRT_LOGGER) as builder, builder.create_network(1) as network, trt.OnnxParser(network, TRT_LOGGER) as parser:
        builder.max_workspace_size = (2 << 30)
        builder.fp16_mode = True
        # builder.int8_mode = True
        with open(onnx_path, 'rb') as model:
            pars_res = parser.parse(model.read())
            if pars_res:
                print("OK ONNX")
                print('Number of errors: {}'.format(parser.num_errors))
            else:
                print('Number of errors: {}'.format(parser.num_errors))
                for err_idx in range(parser.num_errors):
                    error = parser.get_error(err_idx)
                    print('Description of the error: {}'.format(error.desc()))
                    print('Line where the error occurred: {}'.format(error.line()))
                    print('Error code: {}'.format(error.code()))
                    print("Model was not parsed successfully")
        

        # for i in range(network.num_outputs):
        #     out_tensor = network.get_output(i)
        #     if out_tensor is not None:
        #         print(out_tensor.name)
        #         if out_tensor.name != 'prob_map:0':
        #             network.unmark_output(out_tensor)
        #             network.remove_tensor(out_tensor)
        #         else:
        #             print('set output OK')

        engine = builder.build_cuda_engine(network)
        print("ENGINE = ", engine)
        print("NETWORK = ", network)

        return engine

def save_engine(engine, file_name):
   buf = engine.serialize()
   with open(file_name, 'wb') as f:
       f.write(buf)
def load_engine(trt_runtime, plan_path):
   with open(plan_path, 'rb') as f:
       engine_data = f.read()
   engine = trt_runtime.deserialize_cuda_engine(engine_data)
   return engine