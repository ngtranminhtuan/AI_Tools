from sklearn.metrics import multilabel_confusion_matrix
import cv2
import os
import glob
import numpy as np
from run import pad_and_resize
from utils import get_label_info, one_hot_it, reverse_one_hot, evaluate_segmentation_overall, evaluate_segmentation

pred_dir = '/home/nvidia/Users/baoanh/segmentation_suit/data/wire/test/1_pred'
gt_dir = '/home/nvidia/Users/baoanh/segmentation_suit/data/wire/test_labels/1'

pred_paths = glob.glob(os.path.join(pred_dir, '*.*'))
gt_paths = glob.glob(os.path.join(gt_dir, '*.*'))
gt_dict = {}
for gt_path in gt_paths:
    gt_dict[os.path.basename(gt_path).split('.')[0]] = gt_path  

class_names, label_values = get_label_info('/home/nvidia/Users/baoanh/segmentation_suit/data/wire/class_dict.csv')
print(class_names, label_values)

num_classes = len(class_names)
multilabel_confusion_mat = np.zeros((num_classes, 2, 2))
class_iou_list = []

for pred_path in pred_paths:
    pred = reverse_one_hot(one_hot_it(cv2.imread(pred_path), label_values))

    file_name = os.path.basename(pred_path).split('.')[0]
    gt = reverse_one_hot(one_hot_it(pad_and_resize(cv2.imread(gt_dict[file_name])[:512,:512]), label_values))
    
    multilabel_confusion_mat += multilabel_confusion_matrix(
        y_true=gt.flatten(),
        y_pred=pred.flatten(),
        labels=np.arange(num_classes))

    _, _, _, _, _, class_iou, _, _, _ = evaluate_segmentation(pred=pred, label=gt, num_classes=num_classes)
    class_iou_list.append(class_iou)


class_avg_iou_scores = np.mean(class_iou_list, axis=0)
class_avg_prec_scores, class_avg_rec_scores, class_avg_f1_scores = evaluate_segmentation_overall(multilabel_confusion_mat)
print(class_avg_prec_scores, class_avg_rec_scores, class_avg_f1_scores, class_avg_iou_scores)