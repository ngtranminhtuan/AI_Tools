import cv2
import engine as eng
import inference as inf
import tensorrt as trt 
import numpy as np
import time
import glob
import os

def pad_and_resize(img, new_size=(512,512)):
    max_size = max(img.shape[0], img.shape[1])
    out = np.zeros((max_size, max_size, 3), dtype=np.uint8)
    out[:img.shape[0], :img.shape[1]] = img
    return cv2.resize(out, new_size, interpolation=cv2.INTER_NEAREST)

if __name__ == "__main__":
    serialized_plan = "ckpt3/model_false_16.plan"
    HEIGHT = 512
    WIDTH = 512

    engine = eng.load_engine(eng.trt_runtime, serialized_plan)
    h_input, d_input, h_output, d_output, stream = inf.allocate_buffers(engine, 1, trt.float32)

    img_dir = '/home/nvidia/Users/baoanh/segmentation_suit/data/wire/test/1'
    mask_dir = '/home/nvidia/Users/baoanh/segmentation_suit/data/wire/test/1_pred'
    os.makedirs(mask_dir, exist_ok=True)
    img_paths = sorted(glob.glob(os.path.join(img_dir, '*.*')))

    ts = []
    for img_path in img_paths:
        print(img_path)
        input_image = pad_and_resize(cv2.imread(img_path)[:512,:512,::-1])/255.0
        t = time.time()
        output_image = inf.do_inference(engine, input_image, h_input, d_input, h_output, d_output, stream, 1, HEIGHT, WIDTH)
        t = time.time() - t
        ts.append(t)
        print(t)
        mask = (output_image[0,:,:,1] > 0.5).astype(np.uint8)*255
        cv2.imwrite(img_path.replace(img_dir, mask_dir).replace('jpg', 'png'), mask)
    print(np.array(ts)[5:].mean())