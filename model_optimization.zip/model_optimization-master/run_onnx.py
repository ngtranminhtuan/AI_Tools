import onnxruntime as rt
import numpy
import cv2
import numpy as np
import onnx
import time
from run import pad_and_resize

sess = rt.InferenceSession('ckpt/model.onnx')
input_name = sess.get_inputs()[0].name
label_name = sess.get_outputs()[-1].name

input_image = pad_and_resize(cv2.imread('4.jpg')[:,:,::-1])/255.0

ts = []
for i in range(1):
    t = time.time()
    output_image = sess.run([label_name], {input_name:[input_image]})[0][0]
    ts.append(time.time() - t)
    print(output_image[0][0].tolist())
    mask = (output_image[:,:,1] > 0.5).astype(np.uint8)*255
    cv2.imwrite('mask_onnx.png', mask)
print(np.array(ts)[5:].mean())
print(ts)