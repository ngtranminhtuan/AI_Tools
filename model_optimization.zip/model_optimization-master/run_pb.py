import os, time, cv2, sys, math
import tensorflow as tf
import numpy as np
from tensorflow.python.platform import gfile
from run import pad_and_resize

# Initializing network

config = tf.ConfigProto()
config.gpu_options.per_process_gpu_memory_fraction = 0.8
config.gpu_options.allow_growth = True
sess = tf.Session(config=config)

#load freeze graph
with gfile.FastGFile('ckpt/model.pb', 'rb') as f:
    graph_def = tf.GraphDef()
    graph_def.ParseFromString(f.read())
    sess.graph.as_default()    
    tf.import_graph_def(graph_def)

input_tensor = sess.graph.get_tensor_by_name('import/Placeholder:0')
output_tensor = sess.graph.get_tensor_by_name('import/prob_map:0')

input_image = pad_and_resize(cv2.imread('4.jpg')[:512,:512,::-1])/255.0
ts = []
for i in range(1):
    t = time.time()
    output_image = sess.run(output_tensor, feed_dict={input_tensor:[input_image]})[0]
    ts.append(time.time() - t)
    mask = (output_image[:,:,1] > 0.5).astype(np.uint8)*255
    cv2.imwrite('mask_pb.png', mask)
print(ts)