import tensorrt as trt

TRT_LOGGER = trt.Logger(trt.Logger.WARNING)

model_file = 'ckpt/wire2/model.uff'
with trt.Builder(TRT_LOGGER) as builder, builder.create_network() as network, trt.UffParser() as parser:
    parser.register_input("Placeholder", (1, 512, 512, 3))
    parser.register_output("prob_map")
    parser.parse(model_file, network)

# with trt.Builder(TRT_LOGGER) as builder, builder.create_builder_config() as config:
#     config.max_workspace_size = 1 << 20 # This determines the amount of memory available to the builder when building an optimized engine and should generally be set as high as possible.
#     with builder.build_engine(network, config) as engine:
#         # Do inference here.
#         pass
