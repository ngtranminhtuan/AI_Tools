import tensorflow as tf
import numpy as np
import os
from tensorflow.python.platform import gfile


a = tf.placeholder(tf.float32, (1,512,512,3), name='a')
b = tf.nn.batch_normalization(a,1.0,1.0,1.0,1.0,1.0)
c = tf.identity(a-b, name='c')

sess = tf.Session()
sess.run(c, {a: np.ones((1,512,512,3))})

output_graph_def = tf.graph_util.convert_variables_to_constants(sess, sess.graph.as_graph_def(), ['c']) 
# output_graph_def = tf.graph_util.remove_training_nodes(output_graph_def)
with gfile.GFile('test.pb', "wb") as f:
    f.write(output_graph_def.SerializeToString())

# os.system('python3 -m tf2onnx.convert --input test.pb --inputs a:0 --outputs c:0 --output model.onnx --opset 11')
# os.system('python3 engine_build.py')
# os.system('python3 engine_run.py')
