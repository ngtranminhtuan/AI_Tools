import cv2
from tensorflow.python.compiler.tensorrt import trt_convert as trt
import tensorflow as tf
import numpy as np
import time
import os
from run import pad_and_resize
import glob

mode = 'TF_FP32'
# mode = 'TR_FP16'

if mode == 'TF_FP16':
    os.environ["TF_ENABLE_AUTO_MIXED_PRECISION_GRAPH_REWRITE"] = "1"
    os.environ['TF_ENABLE_AUTO_MIXED_PRECISION'] = '1'

config = tf.ConfigProto()
# config.gpu_options.allow_growth = True
# config.gpu_options.per_process_gpu_memory_fraction = 0.5

with tf.Session(config=config) as sess, tf.gfile.GFile('ckpt/model.pb', 'rb') as f:
    frozen_graph = tf.GraphDef()
    frozen_graph.ParseFromString(f.read())

    if mode.split('_')[0] == 'TF':
        sess.graph.as_default()    
        tf.import_graph_def(frozen_graph)
    else:
        converter = trt.TrtGraphConverter(
            input_graph_def=frozen_graph,
            precision_mode=mode.split('_')[1],
            nodes_blacklist=['prob_map'])
        trt_graph = converter.convert()
        tf.import_graph_def(trt_graph)

    input_tensor = sess.graph.get_tensor_by_name('import/Placeholder:0')
    output_tensor = sess.graph.get_tensor_by_name('import/prob_map:0')

    img_dir = '/home/nvidia/Users/baoanh/segmentation_suit/data/wire/test/1'
    mask_dir = '/home/nvidia/Users/baoanh/segmentation_suit/data/wire/test/1_pred'
    os.makedirs(mask_dir, exist_ok=True)
    img_paths = sorted(glob.glob(os.path.join(img_dir, '*.*')))

    ts = []
    for img_path in img_paths:
        print(img_path)
        input_image = pad_and_resize(cv2.imread(img_path)[:512,:512,::-1])/255.0
        t = time.time()
        output_image = sess.run(output_tensor, feed_dict={input_tensor:[input_image]})[0]
        t = time.time() - t
        ts.append(t)
        print(t)
        mask = (output_image[:,:,1] > 0.5).astype(np.uint8)*255
        cv2.imwrite(img_path.replace(img_dir, mask_dir).replace('jpg', 'png'), mask)
    print(np.array(ts)[5:].mean())