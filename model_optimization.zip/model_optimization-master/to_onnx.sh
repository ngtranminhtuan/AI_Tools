python3 -m tf2onnx.convert  \
--input ckpt/model.pb \
--inputs Placeholder:0 \
--outputs prob_map:0 \
--output ckpt/model.onnx \
--opset 11

# python3 -m tf2onnx.convert  \
# --input ckpt/model.pb \
# --inputs Placeholder:0 \
# --outputs Placeholder:0,max_pool:0,Conv_1/BiasAdd:0,Add:0,Conv_5/BiasAdd:0,Conv_6/BiasAdd:0,Add_1:0,Conv_8/BiasAdd:0,Conv_9/BiasAdd:0,Add_2:0,Add_2:0,Conv_12/BiasAdd:0,Conv_13/BiasAdd:0,Add_2:0,Add_3:0,Conv_16/BiasAdd:0,Conv_17/BiasAdd:0,Add_4:0,Conv_19/BiasAdd:0,Conv_20/BiasAdd:0,Add_5:0,Conv_22/BiasAdd:0,Conv_22/BiasAdd:0,concat:0,Add_6:0,Conv_26/BiasAdd:0,Conv_27/BiasAdd:0,Conv_28/BiasAdd:0,Conv_26/BiasAdd:0,Add_7:0,Conv_31/BiasAdd:0,Conv_32/BiasAdd:0,Add_8:0,Conv_34/BiasAdd:0,Conv_34/BiasAdd:0,concat_1:0,Add_9:0,Conv_38/BiasAdd:0,Conv_38/BiasAdd:0,concat_2:0,Add_10:0,Conv_42/BiasAdd:0,Conv_42/BiasAdd:0,concat_3:0,Add_11:0,Conv_46/BiasAdd:0,Conv_46/BiasAdd:0,concat_4:0,Add_12:0,Conv_50/BiasAdd:0,Conv_50/BiasAdd:0,concat_5:0,Add_12:0,Add_13:0,Conv_55/BiasAdd:0,Conv_55/BiasAdd:0,concat_6:0,Add_14:0,Conv_59/BiasAdd:0,Conv_59/BiasAdd:0,concat_7:0,Conv_63/BiasAdd:0,Conv_64/BiasAdd:0,Conv_65/BiasAdd:0,Conv_66/BiasAdd:0,Conv_67/BiasAdd:0,Conv_68/BiasAdd:0,Conv_69/BiasAdd:0,Conv_70/BiasAdd:0,Conv_71/BiasAdd:0,Conv_72/BiasAdd:0,Conv_73/BiasAdd:0,Conv_74/BiasAdd:0,Conv_75/BiasAdd:0,Conv_76/BiasAdd:0,Conv_77/BiasAdd:0,Relu_75:0,concat_9:0,Conv_78/BiasAdd:0,Conv_79/BiasAdd:0,concat_10:0,Conv_80/BiasAdd:0,Conv_81/BiasAdd:0,Conv_82/BiasAdd:0,prob_map:0 \
# --output ckpt/model.onnx \
# --opset 11



# python3 -m tf2onnx.convert  \
# --input ckpt/model_bn.pb \
# --inputs import/Placeholder:0 \
# --outputs import/prob_map:0 \
# --output ckpt/model_bn.onnx \
# --opset 11