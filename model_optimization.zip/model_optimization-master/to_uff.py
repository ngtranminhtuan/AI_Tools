import uff

trt_graph = uff.from_tensorflow_frozen_model('ckpt/model_bn.pb')

with open('ckpt/model.uff', 'wb') as f:
    f.write(trt_graph)