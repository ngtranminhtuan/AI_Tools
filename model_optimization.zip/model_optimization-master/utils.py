from __future__ import print_function, division
import os,time,cv2, sys, math
import tensorflow as tf
import tensorflow.contrib.slim as slim
import numpy as np
import time, datetime
import os, random
#from scipy.misc import imread
# from scipy.misc.pilutil import imread
import ast
from sklearn.metrics import precision_score, \
    recall_score, confusion_matrix, classification_report, \
    accuracy_score, f1_score
import cv2
import itertools
import operator
import csv
import glob

def get_label_info(csv_path):
    """
    Retrieve the class names and label values for the selected dataset.
    Must be in CSV format!

    # Arguments
        csv_path: The file path of the class dictionairy
        
    # Returns
        Two lists: one for the class names and the other for the label values
    """
    filename, file_extension = os.path.splitext(csv_path)
    if not file_extension == ".csv":
        return ValueError("File is not a CSV!")

    class_names = []
    label_values = []
    with open(csv_path, 'r') as csvfile:
        file_reader = csv.reader(csvfile, delimiter=',')
        header = next(file_reader)
        for row in file_reader:
            class_names.append(row[0])
            label_values.append([int(row[1]), int(row[2]), int(row[3])])
        # print(class_dict)
    return class_names, label_values


def one_hot_it(label, label_values):
    """
    Convert a segmentation image label array to one-hot format
    by replacing each pixel value with a vector of length num_classes

    # Arguments
        label: The 2D array segmentation image label
        label_values
        
    # Returns
        A 2D array with the same width and hieght as the input, but
        with a depth size of num_classes
    """
    semantic_map = []
    for colour in label_values:
        equality = np.equal(label, colour)
        class_map = np.all(equality, axis = -1)
        semantic_map.append(class_map)
    semantic_map = np.stack(semantic_map, axis=-1)

    return semantic_map
    
def reverse_one_hot(image):
    """
    Transform a 2D array in one-hot format (depth is num_classes),
    to a 2D array with only 1 channel, where each pixel value is
    the classified class key.

    # Arguments
        image: The one-hot format image 
        
    # Returns
        A 2D array with the same width and hieght as the input, but
        with a depth size of 1, where each pixel value is the classified 
        class key.
    """

    x = np.argmax(image, axis = -1)
    return x


def colour_code_segmentation(image, label_values):
    """
    Given a 1-channel array of class keys, colour code the segmentation results.

    # Arguments
        image: single channel array where each value represents the class key.
        label_values
        
    # Returns
        Colour coded image for segmentation visualization
    """

    colour_codes = np.array(label_values)
    x = colour_codes[image.astype(int)]

    return x
  
def prepare_data_all(dataset_dir):
    train_input_names=[]
    train_output_names=[]
    val_input_names=[]
    val_output_names=[]
    test_input_names=[]
    test_output_names=[]
    for file in os.listdir(dataset_dir + "/train"):
        cwd = os.getcwd()
        train_input_names.append(cwd + "/" + dataset_dir + "/train/" + file)
    for file in os.listdir(dataset_dir + "/train_labels"):
        cwd = os.getcwd()
        train_output_names.append(cwd + "/" + dataset_dir + "/train_labels/" + file)
    for file in os.listdir(dataset_dir + "/val"):
        cwd = os.getcwd()
        val_input_names.append(cwd + "/" + dataset_dir + "/val/" + file)
    for file in os.listdir(dataset_dir + "/val_labels"):
        cwd = os.getcwd()
        val_output_names.append(cwd + "/" + dataset_dir + "/val_labels/" + file)
    for file in os.listdir(dataset_dir + "/test"):
        cwd = os.getcwd()
        test_input_names.append(cwd + "/" + dataset_dir + "/test/" + file)
    for file in os.listdir(dataset_dir + "/test_labels"):
        cwd = os.getcwd()
        test_output_names.append(cwd + "/" + dataset_dir + "/test_labels/" + file)
    train_input_names.sort(),train_output_names.sort(), val_input_names.sort(), val_output_names.sort(), test_input_names.sort(), test_output_names.sort()
    return train_input_names,train_output_names, val_input_names, val_output_names, test_input_names, test_output_names

  
def prepare_data(dataset_dir, srctype = "png", lbltype = "png", subset='**', styled_ratio=[0,0,0]):
    # styled_ratio: ratio of styled train, val, test dataset 
    train_input_names = []
    train_output_names = []
    val_input_names = []
    val_output_names = []
    test_input_names = []
    test_output_names = []

    for file in glob.glob(dataset_dir + "/train/**/*." + srctype):
      train_input_names.append(os.path.abspath(file))
    for file in glob.glob(dataset_dir + "/test/%s/*."%subset + srctype):
      test_input_names.append(os.path.abspath(file))  
    for file in glob.glob(dataset_dir + "/val/**/*." + srctype):
      val_input_names.append(os.path.abspath(file)) 
    
    if(len(train_input_names) == 0):
      print("no files in train/")
    if(len(test_input_names) == 0):
      print("no files in test/")  
    if(len(val_input_names) == 0):
      print("no files in val/") 
      
    #make labels according to source
    for file in train_input_names:
      checklabel = file.replace("/train/", "/train_labels/").replace(srctype, lbltype)
      if(os.path.isfile(checklabel) == True):
        train_output_names.append(checklabel)
      else:
        print("can not find label: " + checklabel)
    
    for file in test_input_names:
      checklabel = file.replace("/test/", "/test_labels/").replace(srctype, lbltype)
      if(os.path.isfile(checklabel) == True):
        test_output_names.append(checklabel)
      else:
        print("can not find label: " + checklabel)

    for file in val_input_names:
      checklabel = file.replace("/val/", "/val_labels/").replace(srctype, lbltype)
      if(os.path.isfile(checklabel) == True):
        val_output_names.append(checklabel)
      else:
        print("can not find label: " + checklabel)
    
    #load styled dataset
    styled_train_input_names = []
    styled_train_output_names = []
    styled_val_input_names = []
    styled_val_output_names = []
    styled_test_input_names = []
    styled_test_output_names = []

    for file in glob.glob(dataset_dir + "/train_styled/**/*." + srctype):
      styled_train_input_names.append(os.path.abspath(file))
    for file in glob.glob(dataset_dir + "/test_styled/%s/*."%subset + srctype):
      styled_test_input_names.append(os.path.abspath(file))  
    for file in glob.glob(dataset_dir + "/val_styled/**/*." + srctype):
      styled_val_input_names.append(os.path.abspath(file)) 
    
    if(len(styled_train_input_names) == 0):
      print("no files in styled train/")
    if(len(styled_test_input_names) == 0):
      print("no files in styled test/")  
    if(len(styled_val_input_names) == 0):
      print("no files in styled val/") 
      
    #make labels according to source
    for file in styled_train_input_names:
      checklabel = file.replace("/train_styled/", "/train_labels_styled/").replace(srctype, lbltype)
      if(os.path.isfile(checklabel) == True):
        styled_train_output_names.append(checklabel)
      else:
        print("can not find label: " + checklabel)
    
    for file in styled_test_input_names:
      checklabel = file.replace("/test_styled/", "/test_labels_styled/").replace(srctype, lbltype)
      if(os.path.isfile(checklabel) == True):
        styled_test_output_names.append(checklabel)
      else:
        print("can not find label: " + checklabel)

    for file in styled_val_input_names:
      checklabel = file.replace("/val_styled/", "/val_labels_styled/").replace(srctype, lbltype)
      if(os.path.isfile(checklabel) == True):
        styled_val_output_names.append(checklabel)
      else:
        print("can not find label: " + checklabel)

    n = [
        [len(train_input_names), len(styled_train_input_names)],
        [len(val_input_names), len(styled_val_input_names)],
        [len(test_input_names), len(styled_test_input_names)],
    ]

    for i, r in enumerate(styled_ratio):
        if r < 1:
            n[i][1] *= r
        elif r > 1:
            n[i][0] *= (1/r)
    
    n = np.array(n).astype(int)
    return (
        train_input_names[: n[0,0]] + styled_train_input_names[: n[0,1]],
        train_output_names[: n[0,0]] + styled_train_output_names[: n[0,1]],
        val_input_names[: n[1,0]] + styled_val_input_names[: n[1,1]],
        val_output_names[: n[1,0]] + styled_val_output_names[: n[1,1]],
        test_input_names[: n[2,0]] + styled_test_input_names[: n[2,1]],
        test_output_names[: n[2,0]] + styled_test_output_names[: n[2,1]]
    )

def load_image(path):
    image = cv2.cvtColor(cv2.imread(path), cv2.COLOR_BGR2RGB)
    return image

# Takes an absolute file path and returns the name of the file without th extension
def filepath_to_name(full_name):
    file_name = os.path.basename(full_name)
    file_name = os.path.splitext(file_name)[0]
    return file_name

# Print with time. To console or file
def LOG(X, f=None):
    time_stamp = datetime.datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
    if not f:
        print(time_stamp + " " + X)
    else:
        f.write(time_stamp + " " + X)


# Count total number of parameters in the model
def count_params():
    total_parameters = 0
    for variable in tf.trainable_variables():
        shape = variable.get_shape()
        variable_parameters = 1
        for dim in shape:
            variable_parameters *= dim.value
        total_parameters += variable_parameters
    print("This model has %d trainable parameters"% (total_parameters))

# Subtracts the mean images from ImageNet
def mean_image_subtraction(inputs, means=[123.68, 116.78, 103.94]):
    inputs=tf.to_float(inputs)
    num_channels = inputs.get_shape().as_list()[-1]
    if len(means) != num_channels:
      raise ValueError('len(means) must match the number of channels')
    channels = tf.split(axis=3, num_or_size_splits=num_channels, value=inputs)
    for i in range(num_channels):
        channels[i] -= means[i]
    return tf.concat(axis=3, values=channels)

def _lovasz_grad(gt_sorted):
    """
    Computes gradient of the Lovasz extension w.r.t sorted errors
    See Alg. 1 in paper
    """
    gts = tf.reduce_sum(gt_sorted)
    intersection = gts - tf.cumsum(gt_sorted)
    union = gts + tf.cumsum(1. - gt_sorted)
    jaccard = 1. - intersection / union
    jaccard = tf.concat((jaccard[0:1], jaccard[1:] - jaccard[:-1]), 0)
    return jaccard

def _flatten_probas(probas, labels, ignore=None, order='BHWC'):
    """
    Flattens predictions in the batch
    """
    if order == 'BCHW':
        probas = tf.transpose(probas, (0, 2, 3, 1), name="BCHW_to_BHWC")
        order = 'BHWC'
    if order != 'BHWC':
        raise NotImplementedError('Order {} unknown'.format(order))
    C = probas.shape[3]
    probas = tf.reshape(probas, (-1, C))
    labels = tf.reshape(labels, (-1,))
    if ignore is None:
        return probas, labels
    valid = tf.not_equal(labels, ignore)
    vprobas = tf.boolean_mask(probas, valid, name='valid_probas')
    vlabels = tf.boolean_mask(labels, valid, name='valid_labels')
    return vprobas, vlabels

def _lovasz_softmax_flat(probas, labels, only_present=True):
    """
    Multi-class Lovasz-Softmax loss
      probas: [P, C] Variable, class probabilities at each prediction (between 0 and 1)
      labels: [P] Tensor, ground truth labels (between 0 and C - 1)
      only_present: average only on classes present in ground truth
    """
    C = probas.shape[1]
    losses = []
    present = []
    for c in range(C):
        fg = tf.cast(tf.equal(labels, c), probas.dtype) # foreground for class c
        if only_present:
            present.append(tf.reduce_sum(fg) > 0)
        errors = tf.abs(fg - probas[:, c])
        errors_sorted, perm = tf.nn.top_k(errors, k=tf.shape(errors)[0], name="descending_sort_{}".format(c))
        fg_sorted = tf.gather(fg, perm)
        grad = _lovasz_grad(fg_sorted)
        losses.append(
            tf.tensordot(errors_sorted, tf.stop_gradient(grad), 1, name="loss_class_{}".format(c))
                      )
    losses_tensor = tf.stack(losses)
    if only_present:
        present = tf.stack(present)
        losses_tensor = tf.boolean_mask(losses_tensor, present)
    return losses_tensor

def lovasz_softmax(probas, labels, only_present=True, per_image=False, ignore=None, order='BHWC'):
    """
    Multi-class Lovasz-Softmax loss
      probas: [B, H, W, C] or [B, C, H, W] Variable, class probabilities at each prediction (between 0 and 1)
      labels: [B, H, W] Tensor, ground truth labels (between 0 and C - 1)
      only_present: average only on classes present in ground truth
      per_image: compute the loss per image instead of per batch
      ignore: void class labels
      order: use BHWC or BCHW
    """
    probas = tf.nn.softmax(probas, 3)
    labels = helpers.reverse_one_hot(labels)

    if per_image:
        def treat_image(prob, lab):
            prob, lab = tf.expand_dims(prob, 0), tf.expand_dims(lab, 0)
            prob, lab = _flatten_probas(prob, lab, ignore, order)
            return _lovasz_softmax_flat(prob, lab, only_present=only_present)
        losses = tf.map_fn(treat_image, (probas, labels), dtype=tf.float32)
    else:
        losses = _lovasz_softmax_flat(*_flatten_probas(probas, labels, ignore, order), only_present=only_present)
    return losses

# crop image following crop_height, crop_width
def image_crop(image, label, crop_height, crop_width):
    if (image.shape[0] != label.shape[0]) or (image.shape[1] != label.shape[1]):
        raise Exception('Image and label must have the same dimensions!')
    if (crop_width <= image.shape[1]) and (crop_height <= image.shape[0]):
        x = int(image.shape[0]/2)
        y = int(image.shape[1]/2) 
        if len(label.shape) == 3:  
            return image[(x-int(crop_height/2)):(x+int(crop_height/2)),(y -int(crop_width/2)):(y +int(crop_width/2)),:], label[(x-int(crop_height/2)):(x+int(crop_height/2)),(y -int(crop_width/2)):(y +int(crop_width/2)),:]
        else: 
            return image[(x-int(crop_height/2)):(x+int(crop_height/2)),(y -int(crop_width/2)):(y +int(crop_width/2))], label[(x-int(crop_height/2)):(x+int(crop_height/2)),(y -int(crop_width/2)):(y +int(crop_width/2))]
    else:
        raise Exception('Crop shape (%d, %d) exceeds image dimensions (%d, %d)!' % (crop_height, crop_width, image.shape[0], image.shape[1]))



# Randomly crop the image to a specific size. For data augmentation
def random_crop(image, label, crop_height, crop_width):
    if (image.shape[0] != label.shape[0]) or (image.shape[1] != label.shape[1]):
        raise Exception('Image and label must have the same dimensions!')
        
    if (crop_width <= image.shape[1]) and (crop_height <= image.shape[0]):
        x = random.randint(0, image.shape[1]-crop_width)
        y = random.randint(0, image.shape[0]-crop_height)
        
        if len(label.shape) == 3:
            return image[y:y+crop_height, x:x+crop_width, :], label[y:y+crop_height, x:x+crop_width, :]
        else:
            return image[y:y+crop_height, x:x+crop_width, :], label[y:y+crop_height, x:x+crop_width]
    else:
        raise Exception('Crop shape (%d, %d) exceeds image dimensions (%d, %d)!' % (crop_height, crop_width, image.shape[0], image.shape[1]))

# Compute the average segmentation accuracy across all classes
def compute_global_accuracy(pred, label):
    total = len(label)
    count = 0.0
    for i in range(total):
        if pred[i] == label[i]:
            count = count + 1.0
    return float(count) / float(total)

# Compute the class-specific segmentation recall
def class_recall_score(pred, label, num_classes):
    total = []
    #extract predicted result
    for val in range(num_classes):
        total.append((label == val).sum())
    #extract positive true of each class
    count = [0.0] * num_classes
    for i in range(len(label)):
        if pred[i] == label[i]:
            count[int(pred[i])] = count[int(pred[i])] + 1.0

    # If there are no pixels from a certain class in the GT, 
    # it returns NAN because of divide by zero
    # Replace the nans with a 1.0.
    recall = []
    for i in range(len(total)):
        if total[i] == 0:
            recall.append(1.0)
        else:
            recall.append(count[i] / total[i])

    return recall

# Compute the class-specific segmentation precision
def class_precision_score(pred, label, num_classes):
    total = []
    #extract actual result
    for val in range(num_classes):
        total.append((pred == val).sum())
    #extract positive true of each class
    count = [0.0] * num_classes
    for i in range(len(label)):
        if pred[i] == label[i]:
            count[int(pred[i])] = count[int(pred[i])] + 1.0

    # If there are no pixels from a certain class in the GT, 
    # it returns NAN because of divide by zero
    # Replace the nans with a 1.0.
    precision = []
    for i in range(len(total)):
        if total[i] == 0:
            precision.append(1.0)
        else:
            precision.append(count[i] / total[i])

    return precision
def compute_class_iou(pred, label, num_classes):
    unique_labels = np.unique(label)
    num_unique_labels = len(unique_labels);

    I = np.zeros(num_unique_labels)
    U = np.zeros(num_unique_labels)
    
    class_iou = []
    for i in range(num_classes):
        class_iou.append(1.0)
    for index, val in enumerate(unique_labels):
        pred_i = pred == val
        label_i = label == val

        I[index] = float(np.sum(np.logical_and(label_i, pred_i)))
        U[index] = float(np.sum(np.logical_or(label_i, pred_i)))
        class_iou[unique_labels[index]] = I[index] / U[index]

    return class_iou
def compute_mean_iou(pred, label):

    unique_labels = np.unique(label)
    num_unique_labels = len(unique_labels);

    I = np.zeros(num_unique_labels)
    U = np.zeros(num_unique_labels)

    for index, val in enumerate(unique_labels):
        pred_i = pred == val
        label_i = label == val

        I[index] = float(np.sum(np.logical_and(label_i, pred_i)))
        U[index] = float(np.sum(np.logical_or(label_i, pred_i)))

    mean_iou = np.mean(I / U)
    return mean_iou


def evaluate_segmentation(pred, label, num_classes, score_averaging="weighted"):
    flat_pred = pred.flatten()
    flat_label = label.flatten()

    global_accuracy = compute_global_accuracy(flat_pred, flat_label)

    prec = precision_score(flat_pred, flat_label, average=score_averaging)
    rec = recall_score(flat_pred, flat_label, average=score_averaging)
    f1 = f1_score(flat_pred, flat_label, average=score_averaging)
    iou = compute_mean_iou(flat_pred, flat_label)
    
    class_iou = compute_class_iou(flat_pred, flat_label, num_classes)
    
    class_rec = class_recall_score(flat_pred, flat_label, num_classes)
    class_precision = class_precision_score(flat_pred, flat_label, num_classes)
    #class_f1_score = f1_score(flat_pred, flat_label, average=None)
    #calculate f1_score per class base on precision and recall
    class_f1_score = []
    #extract actual result
    for count in range(num_classes):
        if class_precision[count]+class_rec[count] == 0:
            class_f1_score.append(0.0)
        else:
            class_f1_score.append(2*class_rec[count]*class_precision[count]/(class_precision[count]+class_rec[count]))
    #class_f1_score = 2*class_rec*class_precision/(class_precision+class_rec)

    return global_accuracy, prec, rec, f1, iou, class_iou, class_f1_score, class_rec, class_precision

    
def compute_class_weights(labels_dir, label_values):
    '''
    Arguments:
        labels_dir(list): Directory where the image segmentation labels are
        num_classes(int): the number of classes of pixels in all images

    Returns:
        class_weights(list): a list of class weights where each index represents each class label and the element is the class weight for that label.

    '''
    image_files = [os.path.join(labels_dir, file) for file in os.listdir(labels_dir) if file.endswith('.png')]

    num_classes = len(label_values)

    class_pixels = np.zeros(num_classes) 

    total_pixels = 0.0

    for n in range(len(image_files)):
        image = imread(image_files[n])

        for index, colour in enumerate(label_values):
            class_map = np.all(np.equal(image, colour), axis = -1)
            class_map = class_map.astype(np.float32)
            class_pixels[index] += np.sum(class_map)

            
        print("\rProcessing image: " + str(n) + " / " + str(len(image_files)), end="")
        sys.stdout.flush()

    total_pixels = float(np.sum(class_pixels))
    index_to_delete = np.argwhere(class_pixels==0.0)
    class_pixels = np.delete(class_pixels, index_to_delete)

    class_weights = total_pixels / class_pixels
    class_weights = class_weights / np.sum(class_weights)

    return class_weights

# Compute the memory usage, for debugging
def memory():
    import os
    import psutil
    pid = os.getpid()
    py = psutil.Process(pid)
    memoryUse = py.memory_info()[0]/2.**30  # Memory use in GB
    print('Memory usage in GBs:', memoryUse)

def evaluate_segmentation_overall(multilabel_confusion_mat):
    classes_tp = multilabel_confusion_mat[:,1,1]
    classes_fp = multilabel_confusion_mat[:,0,1]
    classes_fn = multilabel_confusion_mat[:,1,0]
    classes_precision = classes_tp/(classes_tp+classes_fp)
    classes_recall = classes_tp/(classes_tp+classes_fn)
    classes_f1 = 2*classes_precision*classes_recall/(classes_precision+classes_recall)
    return (classes_precision, classes_recall, classes_f1)